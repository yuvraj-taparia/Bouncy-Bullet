extends Node
class_name Helper

static func map_value(value : float, iStart : float, iEnd : float, oStart : float, oEnd : float) -> float:
	return oStart + (clamp(value, iStart, iEnd) - iStart) / (iEnd - iStart) * (oEnd - oStart);
	pass;
