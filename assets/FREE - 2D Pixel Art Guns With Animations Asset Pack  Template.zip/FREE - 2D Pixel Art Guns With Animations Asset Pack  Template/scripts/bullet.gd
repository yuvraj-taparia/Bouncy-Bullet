extends CharacterBody2D

class_name Bullet

static var impactParticlePrefab = load("res://prefabs/impactParticle.tscn");

@onready var colliderSize : Vector2 = $RicochetCollider.shape.size;
@onready var bulletArea : Area2D = $BulletArea;
var direction = Vector2(0, 0);
@export var speed = 1750;
var damage : float = 0;
var lifeTime : float = 3;
var vel : Vector2 = Vector2.ZERO;
var ricochet : int = 0;
var isPlayer : bool = false;
var collisionPoint : Vector2 = Vector2.INF;

func _ready():
	rotation_degrees = 0;
	pass # Replace with function body.

func set_bullet_velocity(dir : Vector2, spd : float = speed) -> void:
	direction = dir;
	speed = spd;
	vel = direction.normalized() * speed;
	if (ricochet == 0 && (randf_range(0, 1) <= max(0.7, damage / 150) || damage >= 150)):
		ricochet = randi_range(0, 2);

func _process(delta):
	lifeTime -= delta;
	if (lifeTime <= 0):
		queue_free();

func _exit_tree() -> void:
	spawnImpact();

func _physics_process(delta):
	if (damage <= 0):
		queue_free();
	var collider : KinematicCollision2D = move_and_collide(vel * delta, true);
	if (collider != null):
		if (ricochet > 0):
			ricochet -= 1;
			collisionPoint = collider.get_position();
			spawnImpact();
			vel = vel.bounce(collider.get_normal());
		else:
			collisionPoint = collider.get_position();
			queue_free();
	move_and_collide(vel * delta);
	rotation = vel.angle();
	pass

func spawnImpact() -> void :
	if (collisionPoint == Vector2.INF):
		return;
	var impact = impactParticlePrefab.instantiate();
	impact.rotation = rotation + PI + PI / 15 - randf_range(-PI / 5,  PI / 5);
	impact.global_position = collisionPoint;
	Global.gameRoot.call_deferred("add_child", impact);

func has_layer(layer : int, index : int) -> bool:
	return (layer & (1 << index)) != 0;

func add_collision_mask(mask : int) -> void:
	for i in range(0, 32):
		var layer = 1 << i;
		if (mask & layer):
			if (i + 1 == 2):
				isPlayer = true;
			bulletArea.set_collision_mask_value(i + 1, true);
