extends Camera2D

@export var randomStrength: float = 15.0;
@export var SHAKE_FADE: float = 8.0;
@export var OFFSET_MAX_DIST = 10;

var rng = RandomNumberGenerator.new();

var shakeFade : float = SHAKE_FADE;
var shakeStrength: float = 0.0;
var player : Player;
var shakeOffset: Vector2;
var shakeDir : Vector2 = Vector2.ZERO;

func _init():
	Global.camera = self;

func _ready():
	player = get_tree().get_first_node_in_group("player") as Player;
	pass 

func _process(delta):
	if shakeStrength > 0:
		shakeStrength = lerpf(shakeStrength, 0, shakeFade * delta);
		shakeOffset = _random_offset();
	
	if (Engine.time_scale <= 0 && (player != null)):
		position = round(position.slerp(player.position, 0.2) + shakeOffset);
	pass

# Camera Shake
func apply_shake(dir : Vector2 = Vector2.ZERO, strengthMult : float = 1, fadeMult : float = 1):
	shakeStrength = randomStrength * strengthMult;
	shakeFade = SHAKE_FADE * fadeMult;
	shakeDir = dir.normalized();

func _random_offset() -> Vector2:
	if (shakeDir == Vector2.ZERO):
		return Vector2(rng.randf_range(-shakeStrength, shakeStrength),
			rng.randf_range(-shakeStrength, shakeStrength));
	return shakeDir * rng.randf_range(-shakeStrength, shakeStrength);
