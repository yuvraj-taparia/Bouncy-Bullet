extends Node2D

# To make the UI not pixelated while the game is
# I have to spawn stuff in gameRoot
func _init() ->void:
	Global.gameRoot = self;
	pass # Replace with function body.
