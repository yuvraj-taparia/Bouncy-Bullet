extends Node

var player : Player;
var currentStopTime : SceneTreeTimer; 
var camera : Camera2D;
var gameRoot : Node2D;
var crosshair: Crosshair;
var stopping_time : bool = false;

func shake_camera(dir : Vector2 = Vector2.ZERO, strengthMult : float = 1, _fadeMult : float = 1) -> void:
	camera.apply_shake(dir, strengthMult);

# Stop time.
func stop_time(time : float, scale : float = 0.1):
	kill_stop_time();
	if (stopping_time):
		return;
	# Don't stop at 0.0 because there was a bug and i forgot what it was
	Engine.time_scale = clamp(scale, 0.001, 1);
	var timer = get_tree().create_timer(time, false, false, true);
	currentStopTime = timer;
	await timer.timeout;
	Engine.time_scale = 1;

func kill_stop_time() -> void:
	if (currentStopTime != null && currentStopTime.time_left > 0):
		currentStopTime.time_left = 0;
		currentStopTime.timeout.emit();

# This is for the UI Freeze
func unfreeze_time() -> void:
	stopping_time = false;
	Engine.time_scale = 1;

func freeze_time() -> void:
	kill_stop_time();
	stopping_time = true;
	Engine.time_scale = 0;
