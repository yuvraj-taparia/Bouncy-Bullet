extends Node2D
class_name Gun;

static var bulletPrefab = load("res://prefabs/bullet.tscn");
static var casingPrefab = load("res://prefabs/casing.tscn");
static var dropMagPrefab = load("res://prefabs/attachments/dropped_mags/DropMag.tscn");
signal on_reload(reloadTime: float);

var gunType : GunType;
@export_flags_2d_physics var hitMask : int;

@export var recoilRot: float = 0;
@export var recoilPosX: float = 0;
@export var recoilPosY: float = 0;

var spreadMult : float = 0;
var bulletSpawnPoint : Node2D;
var sprite : Node2D;
var spriteAnimator : AnimationTree;
var recoilAnimator : AnimationPlayer;
var parent;
var aimDir : Vector2;
class GunPowerUp:
	var damageInc : float = 0; # This is the percentage added to according places i will be used
	var spreadDec : float = 0;
	var reloadSpeedDec : float = 0;
var powerUp : GunPowerUp = GunPowerUp.new();

var reloadSpeedAnimationInc : float = 1;
var ammoCounter : int;
var fireRateCounter: float = 0;
var reloading : bool = false;
var casingPos : Marker2D;
var dropMagPos : Marker2D;
var dropMagSprite : PackedScene;
var reloadTimer : SceneTreeTimer;
var recoilRotMult : float = 1;
var recoilXMult : float = 1;
var recoilYMult : float = 1;
var moveSpeedInc : float = 0;

func _ready():
	#if (get_parent() is Player):
	parent = get_parent();
	pass

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	if (parent is Player && Input.is_key_label_pressed(KEY_Q)):
		try_play_animation(spriteAnimator, "pickup");
		wait_pickup();
	
	# Sprite rotation and position
	rotation = aimDir.angle();
	var sprPosOffset = sprite.posOffset;
	if (abs(rotation_degrees) <= 90):
		sprite.scale.y = abs(sprite.scale.y) * 1;
		sprPosOffset.y *= 1;
	else:
		sprite.scale.y = abs(sprite.scale.y) * -1;
		sprPosOffset.y *= -1;
	sprite.position = sprPosOffset + Vector2(sprite.recoilPosX * recoilXMult, sprite.recoilPosY * recoilYMult * sign(sprite.scale.y));
	sprite.rotation_degrees = sprite.recoilRot * recoilRotMult * sign(sprite.scale.y);
	if (fireRateCounter > 0):
		fireRateCounter -= delta;

	spriteAnimator.set("parameters/conditions/shooting", false);
	
	pass


func gun_init() -> void:
	moveSpeedInc = 0;
	sprite = gunType.sprite.instantiate();
	assert(sprite != null, gunType.resource_name + " has no sprite wtf");
	add_child(sprite);
	
	bulletSpawnPoint = sprite.get_node(sprite.get_meta("BulletSpawnPoint"));
	assert(bulletSpawnPoint != null, name + " has no bulletSpawnPoint wtf");
	
	spriteAnimator = sprite.get_node(sprite.get_meta("Animator"));
	assert(spriteAnimator != null, name + " has no animator wtf");
	
	recoilAnimator = sprite.get_node(sprite.get_meta("RecoilAnimator"));
	assert(recoilAnimator != null, name + " has no recoil animator wtf");
	ammoCounter = gunType.ammo;
	wait_pickup();
	moveSpeedInc += gunType.moveSpeedInc;

# Wait for the pickup animation to finish
func wait_pickup():
	if (!spriteAnimator.has_animation("pickup")):
		return;
	var pickupAnimation = spriteAnimator.get_animation("pickup");
	fireRateCounter = pickupAnimation.length;


func swapGun(gunResource : GunTypeResource, level: int) -> void:
	if gunResource == null:
		return;
	for child in get_children():
		child.queue_free();
	reloading = false;
	fireRateCounter = 0;
	gunType = gunResource.gun.duplicate();
	gun_init();
	gun_mod_tier(level, gunResource);
	ammoCounter = gunType.ammo;
	pass

# Add upgrade into the gun
func gun_mod_tier(level : int, gunResource: GunTypeResource) -> void:
	var gunVars = sprite as GunVars;
	casingPos = gunVars.casing;
	dropMagPos = gunVars.dropMag;

	# If () : Add Upgrade randomly
	# else: Use default Modification

	var lv : float = float(level) / float(GunGameManager.guns.size());
	if (lv >= 1.0):
		if (randi_range(0, 1) == 0 && gunResource.fullAuto != null):
			var gunModFullAuto = gunResource.fullAuto as GunMod;
			add_gun_mod(gunModFullAuto, gunVars.fullAuto);
		if (!gunResource.mags.is_empty()):
			var gunModMag = gunResource.mags.pick_random() as GunMod;
			dropMagSprite = gunModMag.sprite;
			add_gun_mod(gunModMag, gunVars.mag);
			if (gunModMag.sprite != null):
				gunVars.dropMag.add_child(gunModMag.sprite.instantiate());
	else:
		if (!gunResource.mags.is_empty()):
			var gunModMag = gunResource.mags[0] as GunMod;
			dropMagSprite = gunModMag.sprite;
			add_gun_mod(gunModMag, gunVars.mag);
			if (gunModMag.sprite != null):
				gunVars.dropMag.add_child(gunModMag.sprite.instantiate());
	
	if (lv >= 2.0):
		if (!gunResource.sights.is_empty()):
			var gunModSight = gunResource.sights.pick_random() as GunMod;
			add_gun_mod(gunModSight, gunVars.sight);
		
		if (!gunResource.muzzles.is_empty()):
			var gunModMuzzle = gunResource.muzzles.pick_random() as GunMod;
			add_gun_mod(gunModMuzzle, gunVars.muzzle);
			gunVars.showFlash = gunModMuzzle.showFlash;
	else:
		if (!gunResource.sights.is_empty()):
			var gunModSight = gunResource.sights[0] as GunMod;
			add_gun_mod(gunModSight, gunVars.sight);
		if (!gunResource.muzzles.is_empty()):
			var gunModMuzzle = gunResource.muzzles[0] as GunMod;
			add_gun_mod(gunModMuzzle, gunVars.muzzle);
	
	if (lv >= 3.0):
		if (!gunResource.grips.is_empty()):
			var gunModGrip = gunResource.grips.pick_random() as GunMod;
			add_gun_mod(gunModGrip, gunVars.grip);
		if (!gunResource.stocks.is_empty()):
			var gunModStock = gunResource.stocks.pick_random() as GunMod;
			add_gun_mod(gunModStock, gunVars.stock);
	else:
		if (!gunResource.stocks.is_empty()):
			var gunModStock = gunResource.stocks[0] as GunMod;
			add_gun_mod(gunModStock, gunVars.stock);
	

# Add Gun Modification
func add_gun_mod(mod : GunMod, marker : Marker2D) -> void:
	if (mod.sprite != null):
		marker.add_child(mod.sprite.instantiate());
	if (mod.automatic != -1):
		gunType.automatic = mod.automatic;
	gunType.ammo = ceil(gunType.ammo * (1 + mod.ammoInc));
	ammoCounter = gunType.ammo;
	gunType.damage *= 1 + mod.damageInc;
	gunType.fireRate *= 1 + mod.fireRateInc;
	gunType.reloadSpeed *= 1 + mod.reloadSpeedInc;
	gunType.spreadAngle *= 1 + mod.spreadAngleInc;
	gunType.handlingRotRange *= 1 + mod.handlingRotMult;
	gunType.handlingXRange *= 1 + mod.handlingXMult;
	gunType.handlingYRange *= 1 + mod.handlingYMult;
	if (mod.spreadNumberNew != 0):
		gunType.spreadNumber = mod.spreadNumberNew;
	if (mod.burstAmountNew != 0):
		gunType.burstAmount = mod.burstAmountNew;
	gunType.burstDelay = mod.burstDelayInc;
	moveSpeedInc +=  mod.moveSpeedInc;
	pass



func reload() -> void:
	if (ammoCounter == gunType.ammo || reloading || reloadTimer != null): return;
	if (gunType.isShotgun):
		reloading = true;
		try_play_animation(spriteAnimator, "reload");
		var animationLength = spriteAnimator.get_animation("reload").length;
		on_reload.emit(animationLength);
		await get_tree().create_timer(animationLength).timeout;
		var reloadSpeed = gunType.reloadSpeed * (1 - powerUp.reloadSpeedDec);
		while (ammoCounter < gunType.ammo && reloading):
			reloading = true;
			var timeScale = \
				spriteAnimator.get_animation("reload_bulletIn").length / reloadSpeed;
			spriteAnimator.set("parameters/reload_bulletIn/TimeScale/scale", timeScale);
			try_play_animation(spriteAnimator, "reload_bulletIn");
			reloadTimer = get_tree().create_timer(reloadSpeed);
			on_reload.emit(reloadSpeed);
			await reloadTimer.timeout;
			if (ammoCounter < gunType.ammo && reloading):
				ammoCounter += 1;
		if (reloading):
			try_play_animation(spriteAnimator, "reload_end");
		reloadTimer = null;
		reloading = false;
	else:
		reloading = true;
		var reloadSpeed = gunType.reloadSpeed * (1 - powerUp.reloadSpeedDec);
		on_reload.emit(gunType.reloadSpeed * (1 - powerUp.reloadSpeedDec));
		var timeScale = spriteAnimator.get_animation("reload").length / (reloadSpeed);
		spriteAnimator.set("parameters/reload/TimeScale/scale", timeScale);
		try_play_animation(spriteAnimator, "reload");
		await get_tree().create_timer(reloadSpeed).timeout;
		if (reloading):
			spriteAnimator.set("parameters/reload/TimeScale/scale", timeScale);
			ammoCounter = gunType.ammo;
			fireRateCounter = 0;
			reloading = false;

func shoot():
	# Shoot if it's shotgun and there's ammo
	if (reloading && gunType.isShotgun && ammoCounter > 0):
		reloading = false;
	if (fireRateCounter > 0 || reloading):
		return;
	if (ammoCounter > 0):
		if (parent is Player):
			Global.shake_camera(aimDir, gunType.shakeMultiplier, max(gunType.shakeMultiplier / 2, 1));\
		# So basically this will apply random recoil to the gun animation. It also effects the bullet position
		# if i remember correctly gun modifications will affect these numbers
		recoilRotMult = randf_range(gunType.handlingRotRange.x, gunType.handlingRotRange.y);
		recoilXMult = randf_range(gunType.handlingXRange.x, gunType.handlingXRange.y);
		recoilYMult = randf_range(gunType.handlingYRange.x, gunType.handlingYRange.y);
		bullet_out();
		fireRateCounter = gunType.fireRate + gunType.burstAmount * gunType.burstDelay;
	if (ammoCounter <= 0):
		await get_tree().create_timer(fireRateCounter).timeout;
		reload();

func bullet_out() -> void:
	# Burst
	for i in range(0, clamp(gunType.burstAmount, 1, ammoCounter)):
		if (is_instance_valid(self) == null): return;
		spawn_bullet();
		recoilAnimator.stop(true);
		recoilAnimator.play("recoil");
		spriteAnimator.set("parameters/conditions/shooting", true);
		try_play_animation(spriteAnimator, "shoot");
		# gun
		ammoCounter -= 1;
		#if (parent.has_method("knockback")):
		#	parent.knockback(-aimDir, gunType.knockbackStrength, gunType.knockbackFriction);
		if (parent.has_method("slow_player_down")):
			parent.slow_player_down(gunType.slowDown, 0.3);
		await get_tree().create_timer(gunType.burstDelay).timeout;

func spawn_bullet() -> void:
	for i in range(0, max(1, gunType.spreadNumber)):
		var spreadAngle = gunType.spreadAngle * (1 - powerUp.spreadDec);
		var spread = randf_range(-spreadAngle, spreadAngle);
		if (gunType.spreadNumber <= 1):
			spread *= spreadMult;
		# Setup
		var bullet = bulletPrefab.instantiate() as Bullet;
		Global.gameRoot.add_child(bullet);
		bullet.damage = gunType.damage * (1 + powerUp.damageInc);
		bullet.ricochet = gunType.ricochet;
		
		bullet.global_position = bulletSpawnPoint.global_position;
		bullet.add_collision_mask(hitMask);
		
		bullet.rotation = aimDir.angle();
		bullet.rotation_degrees += spread + sprite.rotation_degrees;
		bullet.set_bullet_velocity(Vector2.from_angle(bullet.rotation));

# Call in gun animation
func spawn_mag() -> void:
	if (dropMagPos != null):
		var dropMag : Sprite2D = dropMagPrefab.instantiate() as Sprite2D;
		if (dropMagSprite != null):
			dropMag.add_child(dropMagSprite.instantiate());
		dropMag.global_position = dropMagPos.global_position;
		dropMag.global_rotation = dropMagPos.global_rotation;
		dropMag.scale.x *= sign(sprite.scale.y);
		Global.gameRoot.add_child(dropMag);

# Call in gun Animation
func spawn_casing() -> void:
	if (casingPos != null):
		var casing : Sprite2D = casingPrefab.instantiate();
		casing.texture = gunType.casing;
		casing.global_position = casingPos.global_position;
		casing.scale.x *= sign(sprite.scale.y);
		Global.gameRoot.add_child(casing);

func try_play_animation(animator : AnimationTree, animation_name : String):
	if (animator.has_animation(animation_name)):
		#animator.get("parameters/playback").stop();
		animator.get("parameters/playback").start(animation_name, true);
	pass
