extends Node2D

signal gun_changed(level : int);

# Gun list
var ConstantGunList : Array[GunTypeResource] = [
	load("res://resources/guns/glock/glock.tres"),
	#load("res://resources/guns/usp/usp.tres"),
	load("res://resources/guns/deserteagle/deserteagle.tres"),
	load("res://resources/guns/m3/m3.tres"),
	#load("res://resources/guns/xm1014/xm1014.tres"),
	#load("res://resources/guns/mp9/mp9.tres"),,
	#load("res://resources/guns/m4a1/m4a1.tres"),
	load("res://resources/guns/ak47/ak47.tres"),
	#load("res://resources/guns/awp/awp.tres"),
];

var guns : Array[GunTypeResource];

func _init() -> void:
	guns = ConstantGunList.duplicate();
