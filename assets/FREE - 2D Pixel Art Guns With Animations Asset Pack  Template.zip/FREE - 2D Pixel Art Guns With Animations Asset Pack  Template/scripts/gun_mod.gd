extends Resource
class_name GunMod

# Gun Modification
# ex: scope, grips, mags, stocks,...

@export var sprite : PackedScene;
#@export var uiTexture : Texture2D;
@export var showFlash : bool = true;
@export_range(-1, 1) var automatic : int = -1;
@export_range(-1, 1) var damageInc : float = 0;
@export_range(-1, 1) var fireRateInc : float = 0;
@export_range(-1, 1) var ammoInc : float = 0;
@export_range(-1, 1) var reloadSpeedInc : float = 0;
@export_range(-1, 1) var spreadAngleInc : float = 0;
@export_range(1, 999999) var spreadNumberNew : int = 0;
@export_range(1, 999999) var burstAmountNew : int = 0;
@export_range(-1, 1) var handlingRotMult : float = 0;
@export_range(-1, 1) var handlingXMult : float = 0;
@export_range(-1, 1) var handlingYMult : float = 0;
@export_range(-1, 1) var burstDelayInc : float = 0;
@export_range(-1, 1) var moveSpeedInc : float = 0;
