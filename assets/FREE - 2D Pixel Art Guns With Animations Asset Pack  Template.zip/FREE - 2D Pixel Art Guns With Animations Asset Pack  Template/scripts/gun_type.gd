extends Resource
class_name GunType;

# Gun Specification
# This stores all the information about the gun

@export_category("Setup")
@export var sprite: PackedScene;
@export var casing: Texture2D;
@export_category("Properties")
# How it shoot
@export var ricochet : int = 0;
@export var automatic : bool = false;
@export var isShotgun : bool = false;
@export var damage: float = 0;
@export var fireRate : float = 0.02;
@export var ammo : int = 30;
@export var reloadSpeed : float = 1;
@export var spreadAngle : float = 0;
@export_range(1, 999999) var spreadNumber : int = 0;
@export_range(1, 999999) var burstAmount : int = 0;
@export var handlingRotRange : Vector2 = Vector2.ONE;
@export var handlingXRange : Vector2 = Vector2.ONE;
@export var handlingYRange : Vector2 = Vector2.ONE;
@export var burstDelay : float = 0;
@export var knockbackStrength : float = 4;
@export var knockbackFriction : float = 80;
@export_range(0, 1) var slowDown : float = 1;
@export_range(-1, 1) var moveSpeedInc : float = 0;
@export var shakeMultiplier : float = 1;
@export_category("Modifications")
# What modifications it has
@export var sights : GunMod;
@export var mags : GunMod;
@export var muzzles : GunMod;
@export var stocks : GunMod;
@export var grips : GunMod;
@export var fullAuto : GunMod;

func _get_configuration_warning():
	if (sprite != null):
		return "bro this doesn't have a sprite";
	pass
