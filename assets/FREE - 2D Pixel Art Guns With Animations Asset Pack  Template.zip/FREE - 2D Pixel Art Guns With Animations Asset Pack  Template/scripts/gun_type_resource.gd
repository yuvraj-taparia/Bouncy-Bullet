extends Resource
class_name GunTypeResource;

# This stores gun and what modifications it can uses
# First Modification will be used as the default mod if the gun hasn't reached specified level

@export_category("Setup")
@export var gun : GunType;
@export var uiName : String;
@export_category("Modifications")
@export var sights : Array[GunMod];
@export var mags : Array[GunMod];
@export var muzzles : Array[GunMod];
@export var stocks : Array[GunMod];
@export var grips : Array[GunMod];
@export var fullAuto : GunMod;
