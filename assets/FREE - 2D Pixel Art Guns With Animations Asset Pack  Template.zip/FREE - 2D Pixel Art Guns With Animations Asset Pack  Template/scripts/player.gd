extends CharacterBody2D
class_name Player

@export_subgroup("Debug")
@export var debugGun : bool = false;
@export var debugGunResource : GunTypeResource;
@export_subgroup("Vars")
@export var speed : float = 100;

var canShoot : bool = false;
var level : int = 1;
var inaccuracy : float = 0;
var aimDir : Vector2 = Vector2.ZERO;
var currentGunIndex : int = 0;

@onready var gun : Gun = $Gun;

func _init() -> void:
	Global.player = self;

func _ready():
	if (debugGun):
		assert(debugGunResource != null, "Cannot debug gun without the damn resource god damn it");
		gun.swapGun(debugGunResource, 100);
	else:
		gun.swapGun(GunGameManager.ConstantGunList[currentGunIndex], 100);
	pass

func _process(_delta : float):
	aimDir = get_global_mouse_position() - global_position;
	gun.aimDir = aimDir;
	if (gun.gunType.automatic):
		canShoot = Input.is_action_pressed("shoot");
	else:
		canShoot = Input.is_action_just_pressed("shoot");
	if (Input.is_action_just_pressed("reload")):
		gun.reload();
	if (Input.is_action_just_pressed("moveLeft")):
		currentGunIndex = (currentGunIndex + GunGameManager.ConstantGunList.size() - 1) % GunGameManager.ConstantGunList.size();
		gun.swapGun(GunGameManager.ConstantGunList[currentGunIndex], 100);
	
	if (Input.is_action_just_pressed("moveRight")):
		currentGunIndex = (currentGunIndex + GunGameManager.ConstantGunList.size() + 1) % GunGameManager.ConstantGunList.size();
		gun.swapGun(GunGameManager.ConstantGunList[currentGunIndex], 100);
	if (Input.is_action_just_pressed("moveUp")):
		gun.swapGun(GunGameManager.ConstantGunList[currentGunIndex], 100);

func _physics_process(_delta: float):
	inaccuracy = min(1, velocity.length() / speed);
	if (Global.crosshair != null):
		var fireRateInaccuracy = gun.fireRateCounter / gun.gunType.fireRate;
		var shootSpread = gun.gunType.spreadAngle * fireRateInaccuracy;
		Global.crosshair.radius = lerpf(Global.crosshair.radius, \
			max(4, 20 * (inaccuracy + shootSpread) * (gun.gunType.spreadAngle / 10)), 0.4);
	if canShoot:
		gun.spreadMult = inaccuracy;
		gun.shoot();
