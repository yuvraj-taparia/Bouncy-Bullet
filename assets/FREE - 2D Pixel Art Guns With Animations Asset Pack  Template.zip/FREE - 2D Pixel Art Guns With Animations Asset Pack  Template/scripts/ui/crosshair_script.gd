extends Control
class_name Crosshair;

@onready var linesControl : Control = $Lines;
@export var radius : float = 4:
	set(newVal):
		radius = clamp(newVal, 4, 80);
		_set_crosshair_size();

func _init() -> void:
	Global.crosshair = self;

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if (Global.player != null):
		Global.player.gun.on_reload.connect(_on_reload);
	_set_crosshair_size();
	pass # Replace with function body.

func _process(_delta: float) -> void:
	position = get_global_mouse_position();
	if (Global.player != null):
		# It will always point from the player's position to the mouse position
		rotation = lerpf(rotation, Global.player.aimDir.angle(), 0.5);

func _on_reload(reloadTime : float) -> void:
	var tween = create_tween();
	tween.tween_property(self, "rotation", rotation + 2 * PI, reloadTime);

func _set_crosshair_size() -> void:
	var childCount = linesControl.get_child_count();
	var index : int = 0;
	for child in linesControl.get_children():
		# Transform it locally because it's confusing
		child = child as TextureRect;
		var angle = deg_to_rad(360.0 * index / childCount);
		child.position = Vector2.from_angle(angle) * radius;
		child.rotation = angle - PI / 2;
		index += 1;
